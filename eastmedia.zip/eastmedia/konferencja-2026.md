# EastMedia 2026: informacje o konferencji

Zebrane 17 listopada 2026 z oficjalnej strony konferencji, strony BPNT i portali lokalnych (źródła na dole). Opisy wystąpień są streszczeniami, nie cytatami z organizatora.

## Najważniejsze fakty

- **Nazwa:** EastMedia 2026: „Marketing, który nadąża za zmianą”
- **Edycja:** 9. (konferencja odbywa się od 2015 roku)
- **Termin:** środa, 18 listopada 2026, 8:30–17:30
- **Miejsce:** Białostocki Park Naukowo-Technologiczny, ul. Żurawia 71, 15-540 Białystok
- **Organizator:** Białostocki Park Naukowo-Technologiczny (BPNT)
- **Bilet:** 249 zł brutto. Firmy działające w BPNT (z prawem do pomocy de minimis) mają 50% zniżki.
- **Rejestracja:** przez eastmedia.com.pl/rejestracja, do 16.11.2026 albo do wyczerpania miejsc. O miejscu na warsztatach decyduje kolejność zgłoszeń.
- **Co obejmuje bilet:** wszystkie 5 prelekcji oraz jeden z wariantów warsztatowych:
  - dwa warsztaty, po jednym w każdej sesji, albo
  - jeden czterogodzinny warsztat o własnym agencie AI (Robert Matyszewski, część I + II), albo
  - same prelekcje (opcja „Nie wezmę udziału” w warsztatach).
- **Akredytacja DIMAQ:** posiadacze certyfikatu DIMAQ dostają punkty recertyfikacyjne: 10 pkt za udział, 30 pkt dla prelegenta.
- **Dla kogo:** przedsiębiorcy, startupy, marketerzy i specjaliści od komunikacji, osoby z regionu, które chcą lepiej korzystać z marketingu i nowych technologii.
- **Kontakt BPNT:** tel. 85 733 39 55, +48 534 653 001, bpnt@bpnt.bialystok.pl

### Co nowego względem 2025

- Jedna prelekcja więcej (5 zamiast 4).
- Nowy format: czterogodzinny warsztat Roberta Matyszewskiego, który trwa przez obie sesje warsztatowe, równolegle z pozostałymi.
- Tematy przewodnie: sztuczna inteligencja, social media, sprzedaż na marketplace'ach (Allegro), reklama, strategia marki, zmiany i współpraca w zespołach.

### Liczby z historii konferencji

- 8 dotychczasowych edycji, ponad 1150 uczestników, 74 prelegentów (strona BPNT o projekcie podaje jeszcze starszą liczbę 64).
- Pierwsze 4 edycje BPNT robił razem z EastCamp Białystok. W 2022, po przerwie pandemicznej, BPNT reaktywował konferencję jako jedyny organizator.

## Agenda

| Godzina | Punkt programu |
|---|---|
| 8:30 | Rejestracja |
| 9:00 | Rozpoczęcie i powitanie |
| 9:15–9:45 | Julian Płonowski: Uniwersalny przepis na sukces na marketplace – od strategii do skalowania sprzedaży |
| 9:50–10:20 | Paweł Wach: Social media w dobie AI. Co dziś daje marce realną przewagę, kiedy możliwości są niemal nieograniczone? |
| 10:25–10:55 | Agnieszka Buśk: Co naprawdę dzieje się w salce konferencyjnej? O różnicach, komunikacji i współpracy |
| 11:00–11:30 | Maciej Sznitowski: Podłącz swojej marce Kroplówkę Komunikacyjną |
| 11:35–12:05 | Kamila Cichocka: Jak technologia zmienia naszą pracę – i jak wprowadzać zmiany w zespołach |
| 12:05–13:00 | Przerwa na lunch |
| 13:00–15:00 | Warsztaty, sesja 1 (do wyboru jeden) |
| 15:00–15:30 | Przerwa na kawę |
| 15:30–17:30 | Warsztaty, sesja 2 (do wyboru jeden) |
| 17:30 | Zakończenie |

### Prelekcje, o czym są

- **Julian Płonowski:** co najbardziej wpływa na sprzedaż na marketplace'ach: strategia, oferta, widoczność, reklama, rentowność i skalowanie. Przykłady polskie i zagraniczne. Otwiera konferencję.
- **Paweł Wach:** co AI realnie zmieniło w social mediach, gdzie są pułapki i w czym marka wciąż może zbudować przewagę.
- **Agnieszka Buśk:** jak różne sposoby myślenia i komunikowania się wpływają na spotkania, decyzje i pracę zespołu.
- **Maciej Sznitowski:** dla małych i średnich firm, które komunikują się zrywami albo wcale. Prosty, mało zasobożerny sposób na regularną komunikację marki.
- **Kamila Cichocka:** technologia, w tym AI, zmienia pracę szybciej niż nasze nawyki. Jak odróżnić trwałą zmianę procesów od chwilowej mody na narzędzie.

### Warsztaty, sesja 1 (13:00–15:00)

- **Wojciech Biendzio – Projekty marketingowe z wykorzystaniem Claude.** Analiza danych z Meta Ads i zasięgów organicznych na Facebooku i Instagramie z pomocą Claude. Wymagana płatna licencja Claude.
- **Agnieszka Buśk – Narzędzia ułatwiające zespołowe szukanie rozwiązań – elementy facylitacji.** Jak prowadzić spotkania, z których wychodzą konkretne decyzje, i jakich błędów unikać.
- **Kamila Cichocka – Jak wprowadzać zmiany technologiczne w zespołach.** Jak komunikować nowe narzędzia, zmniejszać opór, testować bez chaosu i ustalać kolejność zmian.
- **Robert Matyszewski – AI dla menedżerów – od czatu do własnego agenta AI (część I).** Różnice między czatem, automatyzacją a agentem AI. Jak agent pracuje z plikami i narzędziami, jak przygotować mu instrukcje i oceniać wyniki.
- **Marcin Zaniewski – 10 narzędzi w Canvie, które pomogą Ci stworzyć spójny wizerunek marki.** Ustawienia marki, szablony, warstwy, eksport i inne funkcje Canvy.

### Warsztaty, sesja 2 (15:30–17:30)

- **Kamila Kiersznowska – Kampania reklamowa: od celu do optymalizacji.** Planowanie kampanii przed startem (cel, odbiorcy, przekaz, kanały, kreacje, budżet) i czytanie wyników. Uczestnicy wychodzą z jednostronicowym planem i szablonem briefu. Potrzebny laptop albo notes.
- **Robert Matyszewski – Własny agent AI – jak wykorzystać AI w codziennej pracy marketera (część II).** Budowa prostego agenta w Claude Code i baza wiedzy z dokumentów firmy, materiałów marketingowych, brandbooka i planów komunikacji, żeby powtarzalne zadania robić z AI.
- **Julian Płonowski – Nieoczywiste triki na Allegro – jak sprzedawać więcej i wydawać mniej?** Mniej znane sposoby na widoczność ofert, Allegro Ads, rentowność reklam i opłaty. Dla osób, które już sprzedają. Laptop i dostęp do konta Allegro oraz Allegro Ads.
- **Maciej Sznitowski – 4 punkty sensownej strategii marki.** Model w czterech elementach: problem, prawda o kliencie, przewaga konkurencyjna, idea strategiczna. Dla przedsiębiorców bez głębokiej wiedzy marketingowej.
- **Paweł Wach – Gdzie AI naprawdę ma sens w social mediach? Od możliwości do konkretnych wdrożeń.** Gdzie AI pasuje w tworzeniu treści, co przeprojektować przed 2027 rokiem i kiedy zostawić decyzję człowiekowi.

## Warsztat Roberta Matyszewskiego (moduły I i II)

To główna nowość tej edycji, wymieniana we wszystkich zapowiedziach (BPNT, Bstok.pl, Bia24).

- **Tytuł w zapowiedziach:** „AI dla menedżerów – od czatu do własnego agenta AI”
- **Czas:** 13:00–17:30 (część I 13:00–15:00, przerwa, część II 15:30–17:30)
- **Część I (bardziej teoretyczna):** jak przejść od zwykłej rozmowy z AI do zorganizowanej pracy własnego agenta. Czat vs automatyzacja vs agent, praca agenta z plikami i narzędziami, instrukcje, ocena wyników.
- **Część II (praktyczna):** prosty agent w Claude Code i baza wiedzy z materiałów firmy (dokumenty, materiały marketingowe, brandbook, plany komunikacji), użyta do powtarzalnych zadań.
- **Wymagania wpisane na stronie organizatora:**
  - nie trzeba umieć programować,
  - własny laptop, nie starszy niż 5 lat,
  - skonfigurowany dostęp do Claude Code.
- **Uwaga:** warsztat Wojciecha Biendzio w sesji 1 też jest o Claude (wymaga płatnej licencji). Uczestnicy mogą o to pytać albo porównywać.

## Prelegenci

| Osoba | Firma, rola | W skrócie |
|---|---|---|
| Wojciech Biendzio | Bien Agencja, CEO | Białostocka agencja marketingu cyfrowego (Google Ads, Meta Ads, social media), Google Partner, DIMAQ Professional. Szkoli z praktycznego AI i promptów, przeszkolił ponad 700 firm. Partner strategiczny konferencji. |
| Agnieszka Buśk | trenerka, facylitatorka | Blisko 20 lat wspiera organizacje: szkolenia, sesje facylitowane, coaching. Współpraca w zespole i prowadzenie spotkań. |
| Kamila Cichocka | Microsoft, COO; współzałożycielka trust4brand | Blisko 20 lat w branży technologicznej w międzynarodowych firmach. trust4brand to społeczność liderów marketingu i komunikacji. |
| Kamila Kiersznowska | Merkury S.A., Senior Brand Manager | Ponad 15 lat w marketingu, odpowiada za marki Long Chips i Clipper. Kiedyś współorganizowała EastMedia, potem była uczestniczką, teraz jest prelegentką. |
| Robert Matyszewski | prowadzący warsztat o agencie AI | 15 lat w IT na styku technologii, produktu, sprzedaży i biznesu. Wcześniej m.in. SoftwareHut i TenderHut, współtwórca GraphQL Editor. Buduje rozwiązania oparte na AI. |
| Julian Płonowski | JUMICO sp. z o.o., współwłaściciel | Marketplace'y polskie i zagraniczne, od 2023 wspiera sprzedawców (performance, ekspansja). Od 2025 z bratem rozwija markę wokół sprzedaży na Allegro; klienci wygenerowali ponad 150 mln zł sprzedaży. |
| Maciej Sznitowski | Brandoholik.pl, strateg komunikacji marki | Blog Brandoholik, podcast Markotwórstwo, książka „Mała firma, silna marka” (MT Biznes, 2026). Ponad 50 strategii marek MŚP. |
| Paweł Wach | Robimy Social Media, CEO | Autor podcastu Robimy Social Media i szkoleń dla osób zarządzających marketingiem. Nacisk na efektywność i wyniki biznesowe. |
| Marcin Zaniewski | PKK Żubry Białystok, wiceprezes ds. marketingu i komunikacji | Ponad 10 lat w content marketingu i social media, wcześniej 4 lata w Bien Agencji. DIMAQ, Meta/Google/Allegro Ads, e-commerce, marketing sportowy. |

## Partnerzy

- **Organizator:** Białostocki Park Naukowo-Technologiczny
- **Partner strategiczny:** Bien Agencja
- **Partnerzy:** DIMAQ (akredytacja), TOBO, Podlaska Fundacja Rozwoju Regionalnego, Koło Naukowe Marketing 5.0 (Wydział Inżynierii Zarządzania Politechniki Białostockiej)
- **Patroni medialni:** Polskie Radio Białystok, Portal Miejski BiałystokOnline

Logotypy są w `partnerzy/`, zdjęcia prelegentów w `prelegenci/`, agenda jako grafika w `social/agenda.webp`.

## Zasady z regulaminu, które warto znać

- Rezygnacja nie daje zwrotu opłaty. Zgłoszoną osobę można zamienić na inną (do 16.11, mailem do organizatora).
- Organizator może zmienić program (godzinę, prelegenta); zmiany ogłasza na fanpage'u wydarzenia.
- Konferencja jest fotografowana i nagrywana, wizerunek uczestników może trafić do materiałów organizatora. Kto nie chce, zgłasza to do inspektora ochrony danych BPNT.
- Regulamin nie wspomina o certyfikatach ukończenia.

## Dla porównania: EastMedia 2025 (8. edycja)

20 listopada 2025, BPNT, ponad 100 uczestników. Otwierała dyrektorka BPNT Anna Daszuta-Zalewska. Tematy prelegentów: momenty, w których klient zaczyna myśleć o zakupie (Category Entry Points), marketing doświadczeń przy imprezach sportowych, poprawność językowa, employee advocacy, ścieżka klienta w erze AI i wyszukiwania bez kliknięcia, widoczność marki w odpowiedziach AI, wybór agencji i KPI w Meta Ads (Wojciech Biendzio), kampanie społeczne („Żółta Kanapa”), AI w Google Ads i jakość danych. Wnioski z relacji: liczy się jakość danych, na których pracuje AI, i obecność marki w odpowiedziach AI, a nie tylko ruch z wyszukiwarki.

Edycja 2025 była bardziej o widoczności i danych w świecie AI; 2026 idzie krok dalej, w praktyczne wdrażanie AI w pracy zespołów (trzy warsztaty wprost o AI: Biendzio, Wach, Matyszewski, plus Cichocka o zmianach technologicznych).

## Źródła

- [eastmedia.com.pl](https://eastmedia.com.pl/): strona główna, [agenda](https://eastmedia.com.pl/agenda/), [prelegenci](https://eastmedia.com.pl/prelegenci/), [regulamin 2026](https://eastmedia.com.pl/regulamin-udzialu-w-konferencji-eastmedia-2026/), [relacja z 2025](https://eastmedia.com.pl/relacja-eastmedia-2025/)
- [BPNT: EastMedia 2026. Marketing, AI i pomysły do wykorzystania w biznesie](https://bpnt.bialystok.pl/eastmedia-2026-marketing-ai-i-pomysly-do-wykorzystania-w-biznesie/) (13.10.2026)
- [BPNT: wydarzenie EastMedia 2026](https://bpnt.bialystok.pl/wydarzenia-lista/eastmedia-2026-marketing-ktory-nadaza-za-zmiana-2/)
- [BPNT: projekt EastMedia](https://bpnt.bialystok.pl/projekty-lista/eastmedia/)
- [Bstok.pl: EastMedia 2026 w Białymstoku – program konferencji](https://www.bstok.pl/eastmedia-2026-w-bialymstoku-konferencja-e-marketingowa-z-ai-sprzedaza-i-strategia/) (akt. 9.11.2026)
- [Bia24.pl: EastMedia 2026 – trwa rejestracja](https://bia24.pl/kategorie/biznes-i-technologie/eastmedia-2026-marketing,-sztuczna-inteligencja-i-rozwiazania-dla-biznesu.-trwa-rejestracja-na-konferencje.html) (10.11.2026)
- [BiałystokOnline: EastMedia Białystok](https://www.bialystokonline.pl/eastmedia-bialystok,impreza,105214,6,1.html)
